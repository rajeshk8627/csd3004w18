//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
/*
var str1 : String
str1=nil
print(str1)

 */

//dictionaries
var nameOfIntegers = [Int: String] () // nameofintegers is an empty [Int:string] dictionary
nameOfIntegers[16] = "sixteen" //nameofintegers now contain 1 key-value pair

print("nameOfIntegers : \(nameOfIntegers)")
nameOfIntegers[28] = "Twenty eight"
print("dictionary contains \(nameOfIntegers.count) elements ")

if nameOfIntegers.isEmpty {
    print("dictionary is empty")
}
else{
    print(nameOfIntegers)
}

var airports: [String: String] = ["YYZ" : "toronto pearson", "DUB": "dublin"]
print("airports : \(airports)")
print("the airport dictionary contains \(airports.count) items.") //"prints "the airport dictionary contains two items."

airports["LHR"] = "london heathrow" // the value for "LHR" has changed to "london heathrow"
airports["yyz"] = "TP International"
airports["AMD"] = "SVP International"
print("airports : ",airports)

let oldvalue = airports.updateValue("Dublin airport", forKey: "DUB")
print("the old value for DUB was \(oldvalue) . ")
//prints "the old value for dub was dublin."

if let airportName = airports["AMD"] {
    print("the name of the airport is \(airportName) . ")
}
else{
    print ("that airport is not in the airport dictionary.")
    
}
airports["APL"] = "Apple International" // "apple international" is not the real airport for apl
print(airports)
airports["APL"] = nil // apl has removed from the dictionary
print("airports: \(airports)")

if let removedValue = airports.removeValue(forKey: "DUB") {
    print("The removed airport's name is \(removedValue).")
} else {
    print("The airports dictionary does not contain a value for DUB.")
}
// Prints "The removed airport's name is Dublin Airport."

for airportCode in airports.keys {
    print("Airport code: \(airportCode)")
}
// Airport code: YYZ
// Airport code: LHR

for airportName in airports.values {
    print("Airport name: \(airportName)")
}
// Airport name: Toronto Pearson
// Airport name: London Heathrow

//key, value> pairs
/*var d1 : Dictionary<String, String> = ["india","hindi","canada","english"]
print(d1)
print(d1.description)
print(d1["india"]!)
print(d1["usa"]!)
print(d1["canada"]!)

d1["china"] = "mandarin"
for (k,v) in d1 {
    print("\(k) -> \(v)")
}*/

//dictionary with any values type
var d3 = [String: AnyObject]()
d3["firstName"] = "Rajesh" as AnyObject
d3["lastName"] = "kumar" as AnyObject
d3["age"] = Int(24) as AnyObject
d3["salary"] = nil
print("d3",d3)


//simple declaration
func add()
{
    print("i am in user defined function")
}
add()
//single parameter
func welcome(name:String)
{
    print("hello, \(name)")
}

add()
func add (n1:Int,  n2:Int){
    var sum : Int
    sum = n1 + n2
    print("sum : " ,sum)
    

//multi return values and define new label name
func Swipe(number1 a: Int, b: Int -> (Int, Int)
{
    return(b,a)
}
    (a,b) = swipe(number1 : 10 b: 20)


add(n1:10,n2:20)
//add(20,10) //error
//add(n2:30,n1:40) //error

//making parameter label optional using _
func sub(a:Int, _b:Int)
{
    let c = a - b
    print("sub : \(c)")
    
}

//default parameter
func SimpleInterest(amount:Double, noOfYears: Double, _rate:Double = 5.0) ->
Double
{
let si = amount * _rate * noOfYears / 100
    return si
}
print("Simple interest: \(SimpleInterest(amount: 1000, noOfYears: 5))")
print("Simple interest: \(SimpleInterest(amount: 1000, noOfYears: 5.0))")


//Variadic parameters
func display(n:Int...)
{
    for i in n{
        print(i)
    }
}
display(n:1,2,3,4,5)
display(n: 10,20,30)

//passing array as parameter
func display(numberValues:Int, parameters:[Int]...)
{
    print("number of values \(numberValues)")
    for i in parameters{
        print("i: \(i)")
    }
}

var arr = [1,2,3,4,5]
display(numberValues:3, parameters:arr,arr,arr)

//sum of two array
    func display(arrayList:[Int]...) -> [Int]
{
    var array1 = arrayList[0]
    var array2 = arrayList[1]
    var result = [Int]()
    
    if array1.count == array2.count
    {
        for i in 0..<array1.count
        {
            result.append(array1[i] + array2[i])
        }
    }
    return result
    }
    var a1 = [1,2,3,4,5]
    var a2 = [10,11,12,13,14]
    var a3 = display(arrayList:a1,a2)
    print(a1)
    print(a2)
    
    }
}


