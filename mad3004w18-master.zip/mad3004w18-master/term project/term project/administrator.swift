//
//  administrator.swift
//  term project
//
//  Created by MacStudent on 2018-02-05.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Administrator{
    var adminName : String?
    var email : String?
    
    
    init (a_name : String,em : String)
    {
        self.adminName = a_name
        self.email = em
        
    }
}

func updateCatalog() {
    
}
